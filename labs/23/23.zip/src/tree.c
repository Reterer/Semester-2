#include <stdlib.h>
#include "tree.h"

bool t_init(treenodeptr* tree){
    *tree = NULL;
    return true;
}

void t_deinit(treenodeptr* tree){
    if((*tree) == NULL)
        return;
    t_deinit(&(*tree)->child);
    t_deinit(&(*tree)->brother);
    free(*tree);
    *tree = NULL;
}

bool t_insert_before(treenodeptr* tree, T val){
    treenodeptr new_node = malloc(sizeof(treenode));
    if(new_node == NULL)
        return false;

    new_node->val = val;
    new_node->brother = *tree;
    new_node->child = NULL;

    *tree = new_node;
    return true;
}

void t_remove(treenodeptr* root, char* path){
    treenodeptr* tree = t_find_node_by_path(root, path);
    if(tree == NULL || *tree == NULL)
        return;

    treenodeptr  curr_node = *tree;
    *tree = (*tree)->brother;
    curr_node->brother = NULL;
    t_deinit(&curr_node);
}

bool t_add(treenodeptr* root, char* path, T val){
    treenodeptr* select_node = t_find_node_by_path(root, path);
    if(select_node == NULL)
        return false;

    if(t_insert_before(select_node, val) == false){
        fprintf(stderr, "Can't malloc\n");
        return false;
    }
    return true;
}

void _t_print(FILE* f, treenodeptr tree, int level){
    if(tree == NULL)
        return;

    for(int i = 0; i < level; i++)
        fprintf(f, "|\t");

    char str_unit[MAX_UNIT_STR_LEN];
    unit_to_string(tree->val, str_unit);
    fprintf(f, "[%s]\n", str_unit);

    _t_print(f, tree->child, level+1);
    _t_print(f, tree->brother, level);
}

void t_print(FILE* f, treenodeptr* tree){
    _t_print(f, *tree, 0);
    fprintf(f, "\n");
}

void t_func(FILE* f, treenodeptr* root){

}

treenodeptr* t_find_node_by_path(treenodeptr* root, char* path){
    if(*path == '\0')
        return root;
    else if(*root == NULL){
        fprintf(stderr, "Invalid path\n");
        return NULL;
    }

    if(*path == 'c'){
        return t_find_node_by_path(&(*root)->child, path+1);
    }
    else if(*path == 'b'){
        return t_find_node_by_path(&(*root)->brother, path+1);
    }
    else{
        fprintf(stderr, "Invalid path\n");
        return NULL;    
    }
}