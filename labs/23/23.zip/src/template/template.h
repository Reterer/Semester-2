#pragma once 
#define CAT(X,Y) X##_##Y
#define TEMPLATE(X,Y) CAT(X,Y)