#include <log/log.h>

void test_vector();
void test_matrix();

int main() {
    test_vector();
    test_matrix();
}