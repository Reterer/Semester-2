#pragma once

#define T int
#include <vector/vector_template.h>
#undef T

#define T double
#include <vector/vector_template.h>
#undef T
