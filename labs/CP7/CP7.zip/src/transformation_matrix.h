#pragma once
#include "matrix.h"

void transformation_matrix(matrix* mat, double value);
