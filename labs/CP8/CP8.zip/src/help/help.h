#pragma once
#include <stdio.h>

void print_help(FILE* f);