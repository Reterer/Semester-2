#define T int
#include "list/list_template.c"
#undef T