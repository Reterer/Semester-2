#pragma once
#define T int
#include "list/list_template.h"
#undef T