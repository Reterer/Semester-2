void test_list();

int main(){
    test_list();
}